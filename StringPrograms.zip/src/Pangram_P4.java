import java.util.Scanner;

public class Pangram_P4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("=====================================================\nProgram to check string is pangram or not\n=====================================================");
		String s1="";
		
		//Inputting String until it is passed
		do
		{
		System.out.println("Enter string :");
		s1=sc.nextLine();
		if(s1.equals(""))
			System.out.println("Please enter string  dont't pass it blank");
		}while(s1.equals(""));
		
		// initialise array to hold boolean values if characters present
		boolean b[]=new boolean[26];
		int index=0;
		int flag=0;
		for(int i=0;i<s1.length();i++)
		{
			if(s1.charAt(i)>='A' && s1.charAt(i)<='Z')
			{
				index=s1.charAt(i)-'A';
				b[index]=true;
			}
			else if(s1.charAt(i)>='a' && s1.charAt(i)<='z')
			{
				index=s1.charAt(i)-'a';
				b[index]=true;
			}
			
		}
		
		for(int j=0;j<b.length;j++)
		{
			
			if(b[j]==false)
			{
				
				flag=1;
				break;
			}
		}
		
		if(flag==0)
		System.out.println("String "+s1+" is pangram.");
		else
		System.out.println("String "+s1+" is not pangram.");
		
		sc.close();
	}

}
