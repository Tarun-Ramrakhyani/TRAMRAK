import java.util.Scanner;

public class ReverseString_P1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Please enter string to reverse: ");
        StringBuilder inputString=new StringBuilder("");
        inputString.append(sc.nextLine());
        //System.out.println("Entered String is: "+inputString);
        StringBuilder outputString=new StringBuilder("");
        for(int i=inputString.length()-1;i>=0;i--)
        {
        	outputString.append(inputString.charAt(i));
        }
        System.out.println("Reversed String is: \n"+outputString);
        sc.close();
		
}

}
