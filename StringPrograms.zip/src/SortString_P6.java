import java.util.Arrays;
import java.util.Scanner;

public class SortString_P6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println(
				"=====================================================\nProgram to Sort a String\n=====================================================");
		String s1 = new String("");

		// Inputting String until it is passed
		do {
			System.out.println("Enter string :");
			s1 = sc.nextLine();
			if (s1.equals(""))
				System.out.println("Please enter string  dont't pass it blank");
		} while (s1.equals(""));

		
		  
		  StringBuilder lower=new StringBuilder(""); 
		  StringBuilder upper=new StringBuilder("");
		  
		  
		  for(int i=0;i<s1.length();i++)
		  {
			  if(s1.charAt(i)>='A' && s1.charAt(i)<='Z')
				  upper.append(s1.charAt(i));
			  if(s1.charAt(i)>='a' && s1.charAt(i)<='z')
				  lower.append(s1.charAt(i));
			  
		  }
		  
		  
		  char[] lowerArray=new char[lower.length()];
		  char[] upperArray=new char[upper.length()];
		  
		  
		  
		  for(int i=0;i<lower.length();i++)
			  lowerArray[i]=lower.charAt(i);
		  
		  
		  for(int i=0;i<upper.length();i++)
			  upperArray[i]=upper.charAt(i);
		 
		  Arrays.sort(lowerArray); 
		  Arrays.sort(upperArray);
		  
		  
		  
		  StringBuilder sortedArray=new StringBuilder("");
			  for(int i=0;i<lowerArray.length;i++)
			  {
				  sortedArray.append(lowerArray[i]);
			  }
				  for(int j=0;j<upperArray.length;j++)
				  {
					  for(int k=0;k<sortedArray.length();k++)
					  {
						  if(upperArray[j]+32<sortedArray.charAt(k))
						  {
							  sortedArray.insert(k, upperArray[j]);
							  break;
						  }
					  }
				  }
			  
		  System.out.println(sortedArray);
		  
		  
		  
		sc.close();
	}

}
