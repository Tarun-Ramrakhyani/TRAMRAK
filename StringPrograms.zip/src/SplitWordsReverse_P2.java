import java.util.Scanner;

public class SplitWordsReverse_P2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       System.out.println("Please enter input string...");
       Scanner sc=new Scanner(System.in);
       String inputString=new String("");
       inputString=inputString.concat(sc.nextLine());
       String outputString=new String("");
       String temp[]=inputString.split(" ");
       for(int i=0;i<temp.length;i++)
       {
    	   //System.out.println(temp[i]);
    	   //StringBuilder src=new StringBuilder("");
    	   for(int j=temp[i].length()-1;j>=0;j--)
    	   {
    		   outputString=outputString+temp[i].charAt(j);
    	   }
    	   outputString=outputString+" ";
       }
       System.out.println("Output String is: \n"+outputString.toLowerCase());
       
       
       sc.close();
       
       
	}

}
