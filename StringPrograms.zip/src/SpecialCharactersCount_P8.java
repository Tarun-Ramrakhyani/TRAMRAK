import java.util.Scanner;

public class SpecialCharactersCount_P8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("=====================================================\nProgram to count number of special characters\n=====================================================");
		String s1=new String("");
		int specialCharCount=0;
		do
		{
		System.out.println("Enter string :");
		s1=sc.nextLine();
		if(s1.equals(""))
			System.out.println("Please enter string  dont't pass it blank");
		}while(s1.equals(""));
		for(int i=0;i<s1.length();i++)
		{
			if(Character.isLetterOrDigit(s1.charAt(i))==false && Character.isWhitespace(s1.charAt(i))==false)
				specialCharCount++;
		}
		System.out.println("Number of special characters are: "+specialCharCount);
		
		sc.close();
	}

}
