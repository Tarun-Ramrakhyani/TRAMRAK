import java.util.Scanner;

public class RepeatedCharacters_P5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		System.out.println("=====================================================\nProgram to print repeated characters in string\n=====================================================");
		String s1=new String("");
		
		//Inputting String until it is passed
		do
		{
		System.out.println("Enter string :");
		s1=sc.nextLine();
		if(s1.equals(""))
			System.out.println("Please enter string  dont't pass it blank");
		}while(s1.equals(""));
		
		String temp=new String("");
		String s2="";
		for(int i=0;i<s1.length();i++)
		{
			s2=s1.substring(i+1, s1.length());
	        char ch=s1.charAt(i); 
			if(temp.indexOf(ch)==-1) 
			{ 
                int index=s2.indexOf(ch);
			    if(index!=-1 && ch!=' ')
			    	temp=temp.concat(ch+","); 
			}
	
		}
		System.out.println("Repeated character in string are: "+temp.substring(0, temp.length()-1));
		
		sc.close();

	}

}
