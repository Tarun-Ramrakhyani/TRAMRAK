import java.util.Scanner;

public class VowelsConsonantsCount_P7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("=====================================================\nProgram to Count vowels & consonants\n=====================================================");
		String s1=new String("");
		int vowels=0;
		int consonants=0;
		
		//Inputting String until it is passed
		do
		{
		System.out.println("Enter string :");
		s1=sc.nextLine();
		if(s1.equals(""))
			System.out.println("Please enter string  dont't pass it blank");
		}while(s1.equals(""));
		
		s1=s1.toLowerCase();
		for(int i=0;i<s1.length();i++)
		{
			if(s1.charAt(i)=='a' || s1.charAt(i)=='e' || s1.charAt(i)=='i' || s1.charAt(i)=='o' || s1.charAt(i)=='u')
				vowels++;
			else if((s1.charAt(i)>='a' && s1.charAt(i)<='z'))
				consonants++;
		}
		System.out.println("Number of vowels are: "+vowels+" and Number of consonants are: "+consonants);
		sc.close();
	}

}
