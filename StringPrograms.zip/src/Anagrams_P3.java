import java.util.Arrays;
import java.util.Scanner;

public class Anagrams_P3 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("=====================================================\nProgram to check strings are anagram or not\n=====================================================");
		String s1="";
		String s2="";
		
		//Inputting String 1 until it is passed
		do
		{
		System.out.println("Enter string 1:");
		s1=sc.nextLine();
		if(s1.equals(""))
			System.out.println("Please enter string 1 dont't pass it blank");
		}while(s1.equals(""));
		
		//Inputting String 2 until it is passed
		do
		{
		System.out.println("Enter string 2:");
		 s2=sc.nextLine();
		 if(s2.equals(""))
		 System.out.println("Please enter string 2 dont't pass it blank");
		}while(s2.equals(""));
		
		//checking string length are equal or not 
		if(s1.length()!=s2.length())
			System.out.println("Strings "+s1+" and "+s2+" are not Anagram. Because both strings length are different.");
		// checking both strings should not be same
		else if(s1.equals(s2))
			System.out.println("Strings "+s1+" and "+s2+" are not Anagram. Because both Strings are equal.");
		// checking strings anagram or not if above condition not match
		else
		{
			char ch1[]=s1.toCharArray();
			char ch2[]=s2.toCharArray();
			
			Arrays.sort(ch1);
			Arrays.sort(ch2);
			
			boolean result=Arrays.equals(ch1, ch2);
			
			if(result==true)
			System.out.println("Strings "+s1+" and "+s2+" are Anagram");
			else
			System.out.println("Strings "+s1+" and "+s2+" are not Anagram");
				
		}
		sc.close();
		// TODO Auto-generated method stub

	}

}
