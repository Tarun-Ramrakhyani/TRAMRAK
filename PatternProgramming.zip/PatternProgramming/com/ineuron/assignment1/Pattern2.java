package com.ineuron.assignment1;

import java.util.Scanner;

public class Pattern2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Value of n: ");
		int n=sc.nextInt();
		System.out.println("Printing Pattern...\n");
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++)
			{
				if(n<10)
				System.out.print(i+1+" ");
				else
					System.out.print(i+1+"\t");	
			}
			System.out.print("\n");
		}
     sc.close();
	}

}
