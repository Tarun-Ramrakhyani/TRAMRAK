package com.ineuron.assignment1;

public class Pattern1 {

	public static void main(String[] args) {
		 
	        System.out.println("Printing Ineuron Pattern...\n");
			for(int i=0;i<7;i++) {
				for(int j=0;j<55;j++)
				{
					if((j<7) && (i==0 || i==6 || j==3))
						System.out.print("*");
					else if((j>7 && j<15) && (j==8 || j==14 || j-i==8))
						System.out.print("*");
					else if((j>15 && j<23) && (j==16 || i==0 || i==6 || i==3))
						System.out.print("*");
					else if((j>23 && j<31) && (j==24 || j==30 || i==6))
						System.out.print("*");
					else if((j>31 && j<39) && (j==32 || i==0 || (j==38 && i<3 ||i==2 || j-i==30))) 
						System.out.print("*");
					else if((j>39 && j<47) && (j==40 || i==0 || j==46 || i==6))
						System.out.print("*");
					else if((j>47 && j<55) && (j==48 || j==54 || j-i==48))
						System.out.print("*");
					else
						System.out.print(" ");
					
					 
				}
				System.out.print("\n");
		}
			

	}

}
