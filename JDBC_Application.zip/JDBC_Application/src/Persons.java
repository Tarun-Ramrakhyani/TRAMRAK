
public class Persons {

	private String name;
	private String address;
	private String date_of_birth;
	private String date_of_marriage;
	private String date_of_joining;
	private double salary;
	private String persons_photo;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDate_of_birth() {
		return date_of_birth;
	}
	public void setDate_of_birth(String date_of_birth) {
		this.date_of_birth = date_of_birth;
	}
	public String getDate_of_marriage() {
		return date_of_marriage;
	}
	public void setDate_of_marriage(String date_of_marriage) {
		this.date_of_marriage = date_of_marriage;
	}
	public String getDate_of_joining() {
		return date_of_joining;
	}
	public void setDate_of_joining(String date_of_joining) {
		this.date_of_joining = date_of_joining;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getPersons_photo() {
		return persons_photo;
	}
	public void setPersons_photo(String persons_photo) {
		this.persons_photo = persons_photo;
	}
	
	
}
