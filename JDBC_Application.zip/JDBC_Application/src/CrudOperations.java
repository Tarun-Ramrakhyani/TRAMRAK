import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class CrudOperations {
	Scanner sc=new Scanner(System.in);
	Persons p=new Persons();
    Connection con=null;
    PreparedStatement ps=null;
    ResultSet rs=null;
	public void create()
	{
		try {
		System.out.println("Enter Name:: ");
		p.setName(sc.nextLine());
		System.out.println("Enter Address:: ");
		p.setAddress(sc.nextLine());
		System.out.println("Enter Date of Birth in mentioned format (dd-MM-yyyy):: ");
		p.setDate_of_birth(sc.nextLine());	
		System.out.println("Enter Date of Joining in mentioned format (MM-dd-yyyy):: ");
		p.setDate_of_joining(sc.nextLine());
		System.out.println("Enter Date of Marriage in mentioned format (yyyy-MM-dd):: ");
		p.setDate_of_marriage(sc.nextLine());
		System.out.println("Enter Salary:: ");
		p.setSalary(sc.nextDouble());
		
		//System.out.println("Condition Checking...");
		if(p.getName()==null || p.getName()=="" || p.getAddress()==null || p.getAddress()=="" || p.getDate_of_birth()==null || p.getDate_of_birth()==""
		   || p.getDate_of_joining()==null || p.getDate_of_joining()=="" || p.getDate_of_marriage()==null || p.getDate_of_marriage()=="" || p.getSalary()==0)
		{
			System.out.println("Please enter all inputs...");
		}
		else
		{
			// convert string to java.sql.Date for dob
			SimpleDateFormat dob=new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date dobUtil=dob.parse(p.getDate_of_birth());
			java.sql.Date dobsql=new java.sql.Date(dobUtil.getTime());
			 // convert string to java.sql.Date for doj
			SimpleDateFormat doj=new SimpleDateFormat("MM-dd-yyyy");
			java.util.Date dojUtil=doj.parse(p.getDate_of_joining());
			java.sql.Date dojsql=new java.sql.Date(dojUtil.getTime());
			// convert string to java.sql.Date for dom
			SimpleDateFormat dom=new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date domUtil=dom.parse(p.getDate_of_marriage());
			java.sql.Date domsql=new java.sql.Date(domUtil.getTime());

			System.out.println("Photo will be stored...");
			File f=new File("virat.jfif");
			FileInputStream fis=new FileInputStream(f);
			String insertQuery="insert into persons (name,address,date_of_birth,date_of_marriage,date_of_joining,salary,person_photo) values (?,?,?,?,?,?,?)";
		   
			con=JdbcUtil.getConnection();
			if(con!=null)
				ps=con.prepareStatement(insertQuery);
			if(ps!=null)
			{
				ps.setString(1, p.getName());
				ps.setString(2, p.getAddress());
				ps.setDate(3, dobsql);
				ps.setDate(4, dojsql);
				ps.setDate(5, domsql);
				ps.setDouble(6, p.getSalary());			
				ps.setBinaryStream(7, fis);
				int rows=ps.executeUpdate();
				System.out.println(rows+" row inserted");
			}
		}
			}
			catch (SQLException e) {
				System.out.println("Error in performing DB operations...");
			e.printStackTrace();
		    }	
			catch (ParseException e1) {
				System.out.println("Error in performing date format...");
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		   catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   finally
		   {
			   con=null;
			   ps=null;
		   }
		
		

	
		System.out.println();
		new DisplayMenu().displayMenu();
	}
	
	public void retrieve()
	{
		try {
			con=JdbcUtil.getConnection();
			String selectQuery="select id,name,address,date_of_birth,date_of_marriage,date_of_joining,salary from persons";
			if(con!=null)
			{
				ps=con.prepareStatement(selectQuery);
			}
			if(ps!=null)
			{
				rs=ps.executeQuery();
			}
			if(rs!=null)
			{
				//System.out.println("ID\tNAME\tADDRESS\t\tDATE_OF_BIRTH\tDATE_OF_MARRIAGE\tDATE_OF_JOINING\tSALARY");
				while(rs.next())
				{
					SimpleDateFormat dob=new SimpleDateFormat("dd-MM-yyyy");
					String date_of_birth=dob.format(rs.getDate(4));
					
					SimpleDateFormat dom=new SimpleDateFormat("MM-dd-yyyy");
					String date_of_marriage=dom.format(rs.getDate(5));
					
					SimpleDateFormat doj=new SimpleDateFormat("yyyy-MM-dd");
					String date_of_joining=doj.format(rs.getDate(6));
					
					System.out.println("ID:: "+rs.getInt(1) + "\tName:: " + rs.getString(2) + "\tAddress:: " + rs.getString(3)
							+ "\t Date_of_birth:: " +date_of_birth+"\tDate_of_marriage:: "+date_of_marriage+"\tDate_of_joining:: "+date_of_joining+"\t Salary:: "+rs.getDouble(7));
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				JdbcUtil.closeConnection(con, ps, rs);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println();
		new DisplayMenu().displayMenu();
	}
	
	public void update()
	{
		String address="";
		String date_of_joining="";
		double salary=0;
		int id=0;
		int rows=0;
		System.out.println("Enter ID for which datawants to update:: ");
		id=sc.nextInt();
	System.out.println("Only Address, Date_Of_Joining and Salary is allowed to be updated basis ID...");
	String updateOperation=updateMenu();
	try
	{
	  con=JdbcUtil.getConnection();
	if(updateOperation.equalsIgnoreCase("Address"))
	{
		System.out.println("Enter address to update:: ");
		address=sc.next();
		if(con!=null)
		ps=con.prepareStatement("update persons set address=? where id=?");
		if(ps!=null)
		{
			ps.setString(1,address);
			ps.setInt(2, id);
			rows=ps.executeUpdate();
		}
	}
	else if(updateOperation.equalsIgnoreCase("date_of_joining"))
	{
		System.out.println("Enter new date of joining to update in format (MM-dd-yyyy):: ");
		date_of_joining=sc.next();
		SimpleDateFormat doj=new SimpleDateFormat("MM-dd-yyyy");
		java.util.Date dojUtil=doj.parse(date_of_joining);
		java.sql.Date dojsql=new java.sql.Date(dojUtil.getTime());
		if(con!=null)
		{
			ps=con.prepareStatement("update persons set date_of_joining=? where id=?");
			if(ps!=null)
			{
				ps.setDate(1,dojsql);
				ps.setInt(2, id);
				rows=ps.executeUpdate();
			}
		}
	}
	else if(updateOperation.equalsIgnoreCase("salary"))
	{
		System.out.println("Enter salary to update:: ");
		salary=sc.nextDouble();
		if(con!=null)
		{
			ps=con.prepareStatement("update persons set salary=? where id=?");
			if(ps!=null)
			{
				ps.setDouble(1,salary);
				ps.setInt(2, id);
				rows=ps.executeUpdate();
			}
		}
	}
	if(rows!=0 && rows>0)
		System.out.println("Record successfully updated !!");
	else
		System.out.println("No such ID found!!");
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
    finally {
		   try {
			JdbcUtil.closeConnection(con, ps, null);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	   }
	   System.out.println();
	   new DisplayMenu().displayMenu();
	
		
	}
	
	public void delete()
	{
		int rows=0;
	   System.out.println("Records will be deleted using ID only...");
	   System.out.println("Please enter ID for record to delete");
	   int id=sc.nextInt();
	   String deleteQuery="delete from persons where id=?";
	   try {
		con=JdbcUtil.getConnection();
		if(con!=null)
		{
			ps=con.prepareStatement(deleteQuery);
		}
		if(ps!=null)
		{
			ps.setInt(1, id);
			 rows=ps.executeUpdate();
		}
		if(rows>0)
			System.out.println("Record deleted successfully!!");
		else
			System.out.println("No such ID found!!");
			
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	   catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   finally {
		   try {
			JdbcUtil.closeConnection(con, ps, null);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	   }
	   System.out.println();
	   new DisplayMenu().displayMenu();
	}
    
	
	public String updateMenu()
	{
		System.out.println("Enter from below fields which you want to update \n1. Address \n2. Date_Of_Joining \n3. Salary");
		String updateOperation=sc.next();
		return updateOperation;
		
	}
 }
