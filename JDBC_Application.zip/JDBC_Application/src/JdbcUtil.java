import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JdbcUtil {
	
	public static Connection getConnection() throws SQLException
	{
		Connection connection=null;
		String url="jdbc:mysql://localhost:3306/INTRAMRAKSUPUSR";
		String username="root";
		String password="ssdn$1088";
		connection=DriverManager.getConnection(url,username,password);
		if(connection!=null)
		return connection;
		
		return connection;
	}
	
	public static void closeConnection(Connection con,PreparedStatement ps,ResultSet rs) throws SQLException
	{
		if(con!=null)
			con.close();
		if(ps!=null)
			ps.close();
		if(rs!=null)
			rs.close();
	}
	

}
