
import java.util.Scanner;

// This class will display crud operations menu
public class DisplayMenu {
	Scanner sc=new Scanner(System.in);
	public void displayMenu()
	{
		System.out.println("Select one of the crud operations from below:: \n 1. Create \n 2. Retrieve \n 3. Update \n 4. Delete ");
		System.out.println("Please enter operation to perform::");
		String operationSelected=sc.nextLine();
		if(!(operationSelected.equalsIgnoreCase("Create") || operationSelected.equalsIgnoreCase("Retrieve") || operationSelected.equalsIgnoreCase("Update") || operationSelected.equalsIgnoreCase("Delete")))
		{
			System.out.println("Invalid operation selected!! Please select operation from the given menu");
			displayMenu();
		}
		else
		{
			CrudOperations cr=new CrudOperations();
			if(operationSelected.equalsIgnoreCase("Create"))
				cr.create();
			else if(operationSelected.equalsIgnoreCase("Update"))
				cr.update();
			else if(operationSelected.equalsIgnoreCase("Retrieve"))
				cr.retrieve();
			else if(operationSelected.equalsIgnoreCase("Delete"))
				cr.delete();
		}
	}
	
	

}
