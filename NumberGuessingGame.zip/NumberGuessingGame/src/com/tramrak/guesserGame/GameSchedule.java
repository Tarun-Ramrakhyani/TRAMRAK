package com.tramrak.guesserGame;

public class GameSchedule {

	public String matchSchedule(String player1,String player2,String match)
	{
		 // Guesser guessing the number
        Guesser g=new Guesser();
        int guesserNumber=g.guesserGuessNumber(); 
        
		Player p1=new Player();
        System.out.println("\n"+player1+" guess the number: ");
        int p1GuesssedNumber=p1.playerGuessNumber(guesserNumber);
        
        Player p2=new Player();
        System.out.println("\n"+player2+" guess the number: ");
        int p2GuesssedNumber=p2.playerGuessNumber(guesserNumber);
        
        Display d=new Display();
        d.display(guesserNumber, player1, p1GuesssedNumber, player2, p2GuesssedNumber, match);
        
        Umpire u=new Umpire();
        String group1Winner=u.processMatchReults(guesserNumber, player1, p1GuesssedNumber, player2, p2GuesssedNumber, match);
        if(group1Winner.equals("DRAW"))
        {
        	ReMatch rm=new ReMatch();
        	group1Winner=rm.matchSchedule(player1, player2, match);
        	//System.out.println("Winner of " between "+player1+" & "+player2+" is: "+group1Winner);
        	return group1Winner;
        }
        else
        return group1Winner;
        
        
	}
}
