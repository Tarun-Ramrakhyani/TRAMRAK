package com.tramrak.guesserGame;

public class GusserGame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Game Rules:\n\n1) Competiton among 8 players.\n2) Group A Consists of Player 1 , Player 2 , Player 3 , Player 4\n   Group B Consists of Player 5 , Player 6 , Player 7 , Player 8\n3) Guesser can guess number between 1 to 12. \n4) Player should guess numbers lesser than guesser. \n5) Match Schedule: \n   Match 1: Player 1 vs Player 2 \n   Match 2: Player 3 vs Player 4 \n   Match 3: Player 5 vs Player 6 \n   Match 4: Player 7 vs Player 8 \n   Semi-Final 1: Winner of match 1 vs Winner of match 3 \n   Semi-Final 2: Winner of match 2 vs Winner of match 4 \n   Final: Winner of semi-final 1 vs Winner of semi-final 2 \n6) Winners of group A and group B will be playing semi-final against each other and winners of semi-final will be playing finals. \n7) Winners will be decided if below any one criteria is met.\n  a)Player who correctly guess the number will be winner.\n  b)If both the players guessed incorrectly then Player which is close to guessed number will be winner, but if both the players guessed same incorrect number then  winner \n   will be decided by generating random number for both the players and whoever random number is close to guessed number will be the winner.\n  c)If both palyers choosed correctly then it is draw, both players will play again and if they choosed correctly again then winner will be decided by generating random number \n   for both the players and whoever random number is close to guessed number will be the winner.\n\nLet's Begin Number Guessing Game Competition...");
        
        
        
       GameSchedule gc=new GameSchedule();
       
       System.out.println("------------------------\nGroup A matches started\n------------------------\n\n------------------------------\nMatch 1: Player 1 vs Player 2\n------------------------------");
       String match1Winner=gc.matchSchedule("Player 1", "Player 2", "Match 1");
       System.out.println("------------------------------\nWinner of Match 1 is: "+match1Winner+"\n------------------------------");
       
       System.out.println("\n------------------------------\nMatch 2: Player 3 vs Player 4\n------------------------------");
       String match2Winner=gc.matchSchedule("Player 3", "Player 4", "Match 2");
       System.out.println("------------------------------\nWinner of Match 2 is: "+match2Winner+"\n------------------------------");
       System.out.println("--------------------------------------------------------------\nGroup A matches Completed and winners are "+match1Winner+" & "+match2Winner+"\n--------------------------------------------------------------"); 
       
       System.out.println("\n------------------------\nGroup B matches started\n------------------------\n\n------------------------------\nMatch 3: Player 5 vs Player 6\n------------------------------");
       String match3Winner=gc.matchSchedule("Player 5", "Player 6", "Match 3");
       System.out.println("------------------------------\nWinner of Match 3 is: "+match3Winner+"\n------------------------------");
       
       System.out.println("\n------------------------------\nMatch 4: Player 7 vs Player 8\n------------------------------");
       String match4Winner=gc.matchSchedule("Player 7", "Player 8", "Match 4");
       System.out.println("------------------------------\nWinner of Match 4 is: "+match4Winner+"\n------------------------------");
       System.out.println("--------------------------------------------------------------\nGroup B matches Completed and winners are "+match3Winner+" & "+match4Winner+"\n--------------------------------------------------------------"); 
       
       System.out.println("\n-------------------------------\nSemi-Final matches started\n-------------------------------\n\n------------------------------\nSemi-Final 1: "+match1Winner+" vs "+ match3Winner+"\n------------------------------");
       String semiFinal1Winner=gc.matchSchedule(match1Winner, match3Winner, "Semi-Final 1");
       System.out.println("------------------------------\nWinner of Semi-Final 1 is: "+semiFinal1Winner+"\n------------------------------");
       
       System.out.println("\n-------------------------------\nSemi-Final 2: "+match2Winner+" vs "+ match4Winner+"\n------------------------------");
       String semiFinal2Winner=gc.matchSchedule(match2Winner, match4Winner, "Semi-Final 2");
       System.out.println("------------------------------\nWinner of Semi-Final 2 is: "+semiFinal2Winner+"\n------------------------------");
       System.out.println("-----------------------------------------------------\nSemi-Final matches Completed and winners are "+semiFinal1Winner+" & "+semiFinal2Winner+"\n-----------------------------------------------------");
       
       System.out.println("\n------------------------\nFinal match started\n------------------------\n\n------------------------------\nFinal: "+semiFinal1Winner+" vs "+ semiFinal2Winner+"\n------------------------------");
       String finalWinner=gc.matchSchedule(semiFinal1Winner, semiFinal2Winner, "Final");
       System.out.println("--------------------------------------------------\nWinner of Number Guessing competition is: "+finalWinner+"\n--------------------------------------------------\n\nNumber Guessing Game Competition Ended...");
       
       
       
	}

}
