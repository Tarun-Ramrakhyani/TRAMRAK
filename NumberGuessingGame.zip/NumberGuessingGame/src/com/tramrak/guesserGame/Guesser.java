package com.tramrak.guesserGame;

import java.util.Scanner;

public class Guesser {

	 private int guessNumber;
	 Scanner sc=new Scanner(System.in);
	 
	 public int guesserGuessNumber()
	 {
		 System.out.println("\nGuesser guess the number: ");
		 do
		 {
		 guessNumber=sc.nextInt();
		 if(guessNumber<1 || guessNumber>12)
			 System.out.println("\nPlease guess the number between 1 & 12.Please re-guess the number");
		 }
		 while(guessNumber<1 || guessNumber>12);
		 return guessNumber;
	 }
}
