package com.tramrak.guesserGame;

public class Umpire {

	String result;
	public String processMatchReults(int guessNumber,String player1,int p1GuessNumbered,String player2,int p2GuessNumbered,String match)
	{
		
		if(guessNumber==p1GuessNumbered)
		{
			if(guessNumber==p2GuessNumbered)
				{
				if(match.indexOf("Re")==-1)
				{
					result=match+" Drawn. "+player1+" & "+player2+" will play again.";
				    System.out.println("\n"+result);
			    }
				else
				{
					result=match+" Drawn. "+player1+" & "+player2+" will play again for random number generation\n";
				    System.out.println("\n"+result);
				}
				/*
				 * GameSchedule gs=new GameSchedule(); String winner=gs.matchSchedule(player1,
				 * player2, match);
				 */
			    return "DRAW";
			    }
			else
			{
				result=player1+" Won the "+ match+"...";
				System.out.println("\n"+result);
				return player1;
			}
		}
		else if(guessNumber==p2GuessNumbered)
		{
			result=player2+" Won the "+ match+"...";
		    System.out.println("\n"+result);
		    return player2;
		}
		else if(p1GuessNumbered==p2GuessNumbered)
		{
			System.out.println("\nBoth the players guessed the same incorrect number winner will be decided by generating random number for the both the players.");
			GenerateRandomNumber grn=new GenerateRandomNumber();
			String matchWinner=grn.generateRandomNumber(guessNumber, player1, player2, match);
			return matchWinner;
		}
		else
		{
			int player1Diff=guessNumber-p1GuessNumbered;
			int player2Diff=guessNumber-p2GuessNumbered;
			if(player1Diff<player2Diff)
			{
				result="Number Guessed by "+player1+" is close to guessed number "+guessNumber+" so "+player1+" has Won the "+match;
			    System.out.println("\n"+result);
			   return player1;
			}
			else
			{
				result="Number Guessed by "+player2+" is close to  guessed number "+guessNumber+" so "+player2+" has Won the "+match;
			    System.out.println("\n"+result);
			    return player2;
			}
			
		}
	}
}
