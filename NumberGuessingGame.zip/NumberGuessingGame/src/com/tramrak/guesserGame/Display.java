package com.tramrak.guesserGame;

public class Display {
	
	public void display(int guessNumber,String Player1,int p1GuessNumber,String Player2, int p2GuessNumber,String match)
	{
		System.out.println("\nSummary: Number guessed by guesser is: "+guessNumber+", Number guessed by "+Player1+" is: "+p1GuessNumber+" , Number guessed by "+Player2+" is: "+p2GuessNumber);
		System.out.println("Umpire Processing result for: "+match+"...");
	}

}
