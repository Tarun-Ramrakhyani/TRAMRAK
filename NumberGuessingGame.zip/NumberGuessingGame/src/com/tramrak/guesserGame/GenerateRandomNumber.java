package com.tramrak.guesserGame;

import java.util.Random;

public class GenerateRandomNumber {
	
	public String generateRandomNumber(int guessedNumber,String player1,String player2,String match)
	{
		Random random = new Random();
		int randPlayer1 = 0;
		int randPlayer2=0;
		String result="";
		do
		{
		
		// generating random number for player 1
		System.out.println("\nGenerating Random Number for "+player1);
		while (true){
			randPlayer1 = random.nextInt(guessedNumber);
		    if(randPlayer1 !=0) break;
		}
		System.out.println("\nRandom Number generated for "+player1+" is: "+randPlayer1);
		
		// generating random number for player 2
		System.out.println("\nGenerating Random Number for "+player2);
		while (true){
			randPlayer2 = random.nextInt(guessedNumber);
		    if(randPlayer2 !=0) break;
		}
		System.out.println("\nRandom Number generated for "+player2+" is: "+randPlayer2);
		if(randPlayer1==randPlayer2)
			{System.out.println("\nRandom Number for both the players are same, so generating random number again.");}
		}while(randPlayer1==randPlayer2);
		int player1Diff=guessedNumber-randPlayer1;
		int player2Diff=guessedNumber-randPlayer2;
		if(player1Diff<player2Diff)
		{
			result="Random number generated for "+player1+" is close to guessed number "+guessedNumber+" so "+player1+" has Won the "+match;
		    System.out.println("\n"+result+"\n");
		   return player1;
		}
		else
		{
			result="Random number generated for "+player2+" is close to  guessed number "+guessedNumber+" so "+player2+" has Won the "+match;
		    System.out.println("\n"+result+"\n");
		    return player2;
		}
		
		
	}

}
