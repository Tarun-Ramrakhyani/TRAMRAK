package com.tramrak.guesserGame;

import java.util.Scanner;

public class Player {

	private int guessNumber;
	 Scanner sc=new Scanner(System.in);
	 
	 public int playerGuessNumber(int guesserNumber)
	 {
		 do
		 {
		 guessNumber=sc.nextInt();
		 if(guessNumber>guesserNumber)
			 System.out.println("\nPlease guess the number lesser than guesser which is:"+guesserNumber+" .Please re-guess the number");
         }while(guessNumber>guesserNumber);
		 return guessNumber;
	 }
}
