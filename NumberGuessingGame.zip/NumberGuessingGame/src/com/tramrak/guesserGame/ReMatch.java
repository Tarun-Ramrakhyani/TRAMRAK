package com.tramrak.guesserGame;

public class ReMatch {

	public String matchSchedule(String player1,String player2,String match)
	{
		 // Guesser guessing the number
        Guesser g=new Guesser();
        int guesserNumber=g.guesserGuessNumber(); 
        
		Player p1=new Player();
        System.out.println("\n"+player1+" guess the number: ");
        int p1GuesssedNumber=p1.playerGuessNumber(guesserNumber);
        
        Player p2=new Player();
        System.out.println("\n"+player2+" guess the number: ");
        int p2GuesssedNumber=p2.playerGuessNumber(guesserNumber);
        Display d=new Display();
        d.display(guesserNumber, player1, p1GuesssedNumber, player2, p2GuesssedNumber, "Re-"+match);
        
        Umpire u=new Umpire();
   
        String group1Winner=u.processMatchReults(guesserNumber, player1, p1GuesssedNumber, player2, p2GuesssedNumber, "Re "+match);
        if(group1Winner.equals("DRAW"))
        {
        	System.out.println("Both the players "+player1+" & "+player2+" guessed correctly again. Winner will be decided by generating random number for both the players.");
        	GenerateRandomNumber grn=new GenerateRandomNumber();
        	 group1Winner=grn.generateRandomNumber(guesserNumber, player1, player2, match);
        	return group1Winner;
        }
        else
        	return group1Winner;
      }
}
